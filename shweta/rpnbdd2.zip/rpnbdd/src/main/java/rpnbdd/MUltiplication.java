package rpnbdd;

public class MUltiplication extends Operations{
	@Override
	public double calculate(double firstOperand, double secondOperand) {
		// TODO Auto-generated method stub
		return firstOperand*secondOperand;
	}
}
