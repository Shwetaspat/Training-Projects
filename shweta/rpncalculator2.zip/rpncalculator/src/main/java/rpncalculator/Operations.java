package rpncalculator;

public abstract class Operations {
	double result;
	public double calculate(double firstOperand, double secondOperand) {
		return result;
	}
}
